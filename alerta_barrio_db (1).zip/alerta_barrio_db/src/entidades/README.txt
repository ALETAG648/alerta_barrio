Paquete reservado para las clases de entidades (por ejemplo: Reporte, Usuario, Categoria)
que representen las tablas de la base de datos alerta_barrio_db.
