Paquete reservado para las clases DAO (acceso a datos) que implementen las
operaciones CRUD sobre la base de datos alerta_barrio_db (ej: ReporteDAO, UsuarioDAO).
