package alerta_barrio_db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Alerta_barrio_db {

    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3307/alerta_barrio_db";
        String usuario = "root";
        String password = "";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conexion = DriverManager.getConnection(url, usuario, password);

            System.out.println("¡Conexión exitosa a MySQL en XAMPP!");
            conexion.close();
        } catch (ClassNotFoundException e) {
            System.out.println("Error: No se encontró el driver JDBC.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Error al conectar con la base de datos.");
            e.printStackTrace();
        }

        /* Lanza la interfaz gráfica principal de Alerta Barrio */
        java.awt.EventQueue.invokeLater(() -> new presentacion.FrmPrincipal().setVisible(true));
    }
}
