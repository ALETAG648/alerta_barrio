/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package alerta_barrio_db;

/**
 *
 * @author MATIAS
 */
public class pruebaconexion {

}
