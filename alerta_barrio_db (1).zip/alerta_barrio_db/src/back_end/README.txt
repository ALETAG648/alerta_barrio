Paquete reservado para la lógica de backend adicional (validaciones, servicios).
