Paquete reservado para recursos adicionales de interfaz (si se migra a JavaFX o web).
