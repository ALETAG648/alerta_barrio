Paquete reservado para las clases de control/lógica de negocio que conecten
la presentación (formularios) con la capa DAO.
