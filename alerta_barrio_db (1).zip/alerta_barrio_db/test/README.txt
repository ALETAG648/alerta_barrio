Carpeta reservada para pruebas unitarias (JUnit/TestNG) del proyecto Alerta Barrio.
